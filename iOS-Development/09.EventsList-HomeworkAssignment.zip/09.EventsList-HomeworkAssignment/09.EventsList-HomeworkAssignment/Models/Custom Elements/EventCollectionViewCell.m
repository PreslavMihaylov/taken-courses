//
//  EventCollectionViewCell.m
//  09.EventsList-HomeworkAssignment
//
//  Created by Student07 on 4/24/15.
//  Copyright (c) 2015 Mihaylov. All rights reserved.
//

#import "EventCollectionViewCell.h"

@implementation EventCollectionViewCell

@end
